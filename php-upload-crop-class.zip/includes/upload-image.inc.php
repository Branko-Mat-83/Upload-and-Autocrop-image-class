<?php
$upload_image_class= new UploadImageClass();
?>