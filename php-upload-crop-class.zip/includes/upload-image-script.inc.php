<?php
$upload_image_script_class= new UploadImageScriptClass();
?>